. pglet.sh

pglet_page
pglet_send "clean"
pglet_send "add text value='Hello, world!'"