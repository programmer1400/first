# Todo app in Python using Pglet

This directory contains ToDo app for [Python tutorial](https://pglet.io/docs/tutorials/python).

The app requires Python 3.7+ with `pglet` module installed:

    pip install pglet

To run the complete app:

    python todo-complete.py