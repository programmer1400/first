# Pglet Examples

Pglet ("piglet") is a rich user interface (UI) framework for scripts and programs written in any language and a service for securely sharing your application UI.

This repository contains sample applications using [Pglet framework](https://pglet.io) in different languages:

* [Python](python)
* [Bash](bash)
* [PowerShell](powershell)
* [C#](bash)
* [JavaScript](node)
